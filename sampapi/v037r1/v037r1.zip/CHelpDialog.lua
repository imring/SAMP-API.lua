local shared = require 'sampapi.shared'
local ffi = require 'ffi'

shared.ffi.cdef[[
#pragma pack(push, 1)
struct SCHelpDialog {
    IDirect3DDevice9* m_pDevice;
};
typedef struct SCHelpDialog SCHelpDialog;
#pragma pack(pop)
]]

shared.validate_size('struct SCHelpDialog', 0x4)

local CHelpDialog_constructor = ffi.cast('void(__thiscall*)(SCHelpDialog*, IDirect3DDevice9*)', 0x67440)
local function CHelpDialog_new(...)
    local obj = ffi.new('struct SCHelpDialog[1]')
    CHelpDialog_constructor(obj, ...)
    return obj
end

local SCHelpDialog_mt = {
    Show = ffi.cast('void(__thiscall*)(SCHelpDialog*)', shared.GetAddress(0x67450)),
}
SCHelpDialog_mt.__index = SCHelpDialog_mt
ffi.metatype('struct SCHelpDialog', SCHelpDialog_mt)

local function RefHelpDialog() return ffi.cast('SCHelpDialog**', shared.GetAddress(0x21A0D8))[0] end

return {
    new = CHelpDialog_new,
    RefHelpDialog = RefHelpDialog,
}